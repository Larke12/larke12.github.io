#ifndef PLAYER_H
#define PLAYER_H

#include <stdlib.h>
#include "Const.h"
#include "Console.h"

// Define Player struct
struct Player{
	int x_loc;
	int y_loc;
	int dx_vel;
	int dy_vel;
	char c;
	int color;
	int score;
};

void initialize_Player(struct Player *p, int x, int y, int dx, int dy, char c, int color);
void draw_Player(struct Player *p);
void player_AI(struct Player *ai, int board[HEIGHT][WIDTH]);
void check_Player_Move(struct Player *p, int board[HEIGHT][WIDTH]);
void update_Player(struct Player *p);
void ghost_AI(struct Player *p, int board[HEIGHT][WIDTH]);

#endif // PLAYER_H
