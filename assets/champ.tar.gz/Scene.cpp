#include "Scene.h"

// Initialize variables and characters
void initialize_Scene(struct Scene *s)
{
	load_Board(s->board, &s->num_pellets, &s->num_powerups, &s->level);
	initialize_Player(&s->p, PLAYER_HOME_X, PLAYER_HOME_Y, 0, 0, PLAYER_CHAR, PLAYER_COLOR);
	
	// Ghost initializer
	int home = 0;
	for(int i = 0; i < NUM_GHOSTS; i++){
		int dx = (rand() % 1) - 2;
		while(dx == 0){
			dx = (rand() % 1) - 2;
		}
		initialize_Player(&s->ghost[i], GHOST_HOME_X, GHOST_HOME_Y + home, dx, 0, GHOST_CHAR, GHOST_COLOR);
		home += 2;
	}
}
// Draw graphics
void render_Scene(struct Scene *s)
{
	draw_Board(s->board);
	
	// Print score
	cons_move_cursor(0, WIDTH);
	cons_change_color(YELLOW, BLACK);
	cons_printw(" SCORE %i", s->p.score);
	
	// Print level
	cons_move_cursor(2, WIDTH);
	cons_change_color(YELLOW, BLACK);
	cons_printw(" LEVEL %i", s->level+1);
	
	// Print characters code
	draw_Player(&s->p);
	for(int i = 0; i < NUM_GHOSTS; i++){
		draw_Player(&s->ghost[i]);
	}
}

// Routine to update scene
int update_Scene(struct Scene *s)
{
	
	// Character updates
	player_AI(&s->p, s->board);
	update_Player(&s->p);
	s->tmr++;
	if(s->tmr == GHOST_DELAY){
		for(int i = 0; i < NUM_GHOSTS; i++){
			ghost_AI(&s->ghost[i], s->board);
			update_Player(&s->ghost[i]);
			s->tmr = 0;
		}
	}
	
	// Scoring
	if(s->board[s->p.x_loc][s->p.y_loc] == PELLET){
		s->board[s->p.x_loc][s->p.y_loc] = EMPTY;
		s->p.score += PELLET_VAL;
		s->num_pellets--;
	}
	if(s->board[s->p.x_loc][s->p.y_loc] == POWER_UP){
		s->board[s->p.x_loc][s->p.y_loc] = EMPTY;
		s->p.score += POWER_VAL;
		s->num_powerups--;
		
		// Capture sequence -- NOT OPERATIONAL	
		for(int i = s->pwr; i > 0; i--){
			// Change ghost color to capture color
			for(int ghst = 0; ghst < NUM_GHOSTS; ghst++){
				s->ghost[ghst].color = CAP_COLOR;
			}
			
			// Capture scoring
			for(int ghst = 0; ghst < NUM_GHOSTS; ghst++){
				if((s->p.x_loc == s->ghost[ghst].x_loc) && (s->p.y_loc == s->ghost[ghst].y_loc)){
					s->p.score += CAP_VAL;
					s->ghost[ghst].color = GHOST_COLOR;
				}
			}
			
			// Reset color
			for(int ghst = 0; ghst < NUM_GHOSTS; ghst++){
				s->ghost[ghst].color = GHOST_COLOR;
			}
		}
	}
	
	// Win new level
	if(s->num_powerups == 0){// && s->num_pellets == 0){
		if(s->level == 2){ // Three level limiter
			return 1;
		}
		s->level++;
		initialize_Scene(s);
	}
	
	// Loss game over
	for(int ghst = 0; ghst < NUM_GHOSTS; ghst++){
		if((s->p.x_loc == s->ghost[ghst].x_loc) && (s->p.y_loc == s->ghost[ghst].y_loc)){
			return 1;
		}
	}
	
	return 0;
}

// Routine to load board from text file
void load_Board(int board[HEIGHT][WIDTH], int *num_pellets, int *num_powerups, int *level)
{
	FILE* in;
	char ch;
	int i,j;
	
	*num_pellets = 0;
	*num_powerups = 0;
	
	// Level select
	if(*level == 0){
		in = fopen("board.txt","r"); // Default board
	}
	if(*level == 1){
		in = fopen("board2.txt","r"); // Level 2
	}
	if(*level == 2){
		in = fopen("board3.txt","r"); // Bonus level
	}
	
	if(!in)
	{
		printf("Unable to open file.");
		exit(0);
	}

	for(i=0; i<HEIGHT; i++)
	{
		for(j=0; j<WIDTH; j++)
		{
			fscanf(in,"%c",&ch);
			if(ch=='+')
			{
				board[i][j] = WALL;
			}
			else if(ch=='.')
			{
				board[i][j] = PELLET;
				(*num_pellets)++;
			}
			else if(ch=='O')
			{
				board[i][j] = POWER_UP;
				(*num_powerups)++;
			}
			else
			{
				board[i][j] = EMPTY;
			}
		}
		fscanf(in,"%c",&ch);
		fscanf(in,"%c",&ch);
	}

	fclose(in);

	return;
}
// Draw board from board.txt file
void draw_Board(int board[HEIGHT][WIDTH])
{
	// Loop for printing wall, pellet, and power up characters
	for(int i = 0; i < HEIGHT; i++){
		for(int j = 0; j < WIDTH; j++){
			if(board[i][j] == WALL){
				cons_change_color(BLACK, BLUE);
				cons_move_cursor(i,j);
				cons_printw("%c", WALL_CHAR);
			}else if(board[i][j] == PELLET){
				cons_change_color(WHITE, BLACK);
				cons_move_cursor(i,j);
				cons_printw("%c", PELLET_CHAR);
			}else if(board[i][j] == POWER_UP){
				cons_change_color(RED+INTENSE, BLACK);
				cons_move_cursor(i,j);
				cons_printw("%c", POWER_CHAR);
			}
		}
	}
}
