#ifndef SCENE_H
#define SCENE_H

#include <stdio.h>
#include <stdlib.h>
#include "Console.h"
#include "Const.h"
#include "Player.h"

// Define Scene struct
struct Scene {
	int board[HEIGHT][WIDTH];
	int num_pellets;
	int num_powerups;
	struct Player p;
	struct Player ghost[NUM_GHOSTS];
	int tmr; // Timer for ghosts, counts up
	int level; // Level number, 0 = Level 1
	int pwr; // Power-up timer, counts down
};

void initialize_Scene(struct Scene *s);
void render_Scene(struct Scene *s);
int update_Scene(struct Scene *s);
void load_Board(int board[HEIGHT][WIDTH], int *num_pellets, int *num_powerups, int *level);
void draw_Board(int board[HEIGHT][WIDTH]);

#endif // SCENE_H
