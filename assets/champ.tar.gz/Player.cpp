#include "Player.h"

// Set starting point of player
void initialize_Player(struct Player *p, int x, int y, int dx, int dy, char c, int color){
	p->x_loc = x;
	p->y_loc = y;
	p->dx_vel = dx;
	p->dy_vel = dy;
	p->c = c;
	p->color = color;
	p->score = 0;
}

// Draw player
void draw_Player(struct Player *p){
	cons_move_cursor(p->x_loc, p->y_loc);
	cons_change_color(p->color, BLACK);
	cons_printw("%c", p->c);
}

// Player controls
void player_AI(struct Player *p, int board[HEIGHT][WIDTH]){
	
	int key = cons_get_keypress();
	
	if(key == UP_ARROW){
		p->dy_vel = 0;
		p->dx_vel = -1;
	}else if(key == DOWN_ARROW){
		p->dy_vel = 0;
		p->dx_vel = 1;
	}else if(key == LEFT_ARROW){
		p->dy_vel = -1;
		p->dx_vel = 0;
	}else if(key == RIGHT_ARROW){
		p->dy_vel = 1;
		p->dx_vel = 0;
	}else{
		p->dy_vel = 0;
		p->dx_vel = 0;
	}
	check_Player_Move(p, board);
}

// Check legality of the move of the player
void check_Player_Move(struct Player *p, int board[HEIGHT][WIDTH]){
	
	// Wall collision
	if(board[p->x_loc + p->dx_vel][p->y_loc + p->dy_vel] == WALL){
		p->dy_vel = 0;
		p->dx_vel = 0;
	}
	
	// Tunnel teleport
	if((p->x_loc == TUNNEL_Y && p->y_loc == 0)){
		p->x_loc = TUNNEL_Y;
		p->y_loc = WIDTH-2;
	}else if((p->x_loc == TUNNEL_Y && p->y_loc == WIDTH-1)){
		p->x_loc = TUNNEL_Y;
		p->y_loc = 1;
	}
}

// Update player symbol
void update_Player(struct Player *p){
	p->x_loc += p->dx_vel;
	p->y_loc += p->dy_vel;
}

// Move ghosts (basic AI)
void ghost_AI(struct Player *p, int board[HEIGHT][WIDTH]){
	
	int dictate = rand() % 4;
	
	if(dictate == 0){
		p->dy_vel = 0;
		p->dx_vel = 1;
	}else if(dictate == 1){
		p->dy_vel = 1;
		p->dx_vel = 0;
	}else if(dictate == 2){
		p->dy_vel = 0;
		p->dx_vel = -1;
	}else if(dictate == 3){
		p->dy_vel = -1;
		p->dx_vel = 0;
	}
	
	check_Player_Move(p, board);
}

